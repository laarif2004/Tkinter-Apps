from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QApplication
contact={"nasri":{"phone_number":"5654985613","relationship":"relative",
                  "events":[["concert"],["240623"],["24/06/23"],["4:30 PM"]],
                  "notes":["friendly"],"email":"malekeng@gmail.com",
                  "tasks":{"homework":{"time":"24/06/02","priority":"H"}}
                  ,"task_memory":[["homework"],["24/06/02"],["H"]]},
         "mahmoud":{"phone_number":"416969234","relationship":"classmate",
                    "events":[['hackathon'],['240214'],['24/02/14'],['2:00 PM']],
                    "notes":'["intelligent","plays videogames"]',"email":"mahmoudguesmi@gmail.com",
                    "tasks":{"study":{"time":"24/05/04","priority":"H"}}
                    ,"task_memory":[["study"],["24/05/04"],["H"]]}}

def permutation(x,y):
    a=x
    x=y
    y=a
    return(x,y)
def namet(n):
    return(n in contact)
def add():
    ta=[]
    ti=[]
    tp=[]
    n=input("Name: ")
    n1={}
    p=input("Phone number: ")
    n1['phone_number']=p
    e=input("Email: ")
    n1['email']=e
    r=input("Relationship")
    n1["relationship"]=r
    n1["task_memory"]=[ta,ti,tp]
    contact[n]=n1
    contact[n]["notes"]=[]
    print("Contact added successfully!")
    print(contact[n])
    return(contact)
def search_n():
    n=input("Search name: ")
    if n in contact:
        print("Contact found! Check your app")
        f.a1.setText(n)
        f.a2.setText(contact.get(n).get("phone_number"))
        f.a3.setText(contact.get(n).get("email"))
        f.a4.setText(contact.get(n).get("relationship"))
        f.l1.setText("Name")
        f.l2.setText("Phone Number")
        f.l3.setText("Email")
        f.l4.setText("Relationship")
    else:
        print("contact not found")
        f.a1.setText("")
        f.a2.setText("")
        f.a3.setText("")
        f.a4.setText("")
def edit():
    n=input("Name: ")
    if n in contact:
        print("1:Phone Number")
        print("2:Email")
        print("3:Relationship")
        a=int(input("enter the number corresponding to the category to edit: "))
        if a==1:
            p=input("Enter a new phone number")
            contact.get(n)["phone_number"]=p
            print("Change saved successfully!")
        if a==2:
            p=input("Enter a new email")
            contact.get(n)["email"]=p
            print("Change saved successfully!")
        if a==3:
            p=input("Update the new relationship: ")
            contact.get(n)["relationship"]=p
            print("Change saved successfully!")
        else:
            print("irrelevant input, action cancelled")
    else:
        while n not in contact:
            n=input("name not found, try again or type 'cancel' ")
            if n=="cancel":
                break
def delete():
    n=input("Enter name to delete: ")
    if namet(n):
        a=input("confirm action ? (y/n) ")
        if a.upper()=="Y":
            contact.pop(n)
            print("Contact:",n,"--> deleted")
        else:
            print("Cancelled")
    else:
        print("name not found")
def add_task():
    
    n=input('Name: ')
    if namet(n):
        contact.get(n)["tasks"]={}
        t=input("add a task:")
        contact.get(n).get("task_memory")[0].append(t)
        T={}
        i=input("deadline in YYY/MMM/DDD")
        contact.get(n).get("task_memory")[1].append(i)
        T["time"]=i
        p="0"
        while p.upper()!="H" and p.upper()!="L":
            p=input("Priority (H-high / L-low ):")
        T["priority"]=p.upper()
        contact.get(n).get("task_memory")[2].append(p.upper())
        contact.get(n).get("tasks")[t]=T
        print("Task added successfully!")
    else:
        print("name not found")
def sort_by_priority(a1,a2,a3):
    test=False
    while test==False:
        test=True
        for i in range(len(a1)-1):
            if a3[i+1].upper()=="H" and a3[i].upper()=="L":
                    a1[i+1],a1[i]=permutation(a1[i+1],a1[i])
                    a2[i+1],a2[i]=permutation(a2[i+1],a2[i])
                    a3[i+1],a3[i]=permutation(a3[i+1],a3[i])
                    test=False
    return(a1,a2,a3)
def format_(t):
    a=t[:]
    while len(a)!=5:
        a.append("-")
    return(a)
def sort_task():
    n=input("Name")
    if namet(n):
        ta=contact.get(n).get("task_memory")[0]
        ti=contact.get(n).get("task_memory")[1]
        tp=contact.get(n).get("task_memory")[2]
        ta,ti,tp=sort_by_priority(ta,ti,tp)
        ta,ti,tp=format_(ta),format_(ti),format_(tp)
        f.l1.setText(ta[0])
        f.a1.setText(ti[0])
        f.z1.setText(tp[0])
        f.l2.setText(ta[1])
        f.a2.setText(ti[1])
        f.z2.setText(tp[1])
        f.l3.setText(ta[2])
        f.a3.setText(ti[2])
        f.z3.setText(tp[2])
        f.l4.setText(ta[3])
        f.a4.setText(ti[3])
        f.z4.setText(tp[3])
        f.l5.setText(ta[4])
        f.a5.setText(ti[4])
        f.z5.setText(tp[4])
        print("name found! Check your app")
    else:
        print("name not found")
def task_c():
    n=input("Name")
    if namet(n):
        a=input("specify which task is compelete: ")
        if a in contact.get(n)["tasks"]:
            contact.get(n)["tasks"].get(a).update({"state":"completed"})
            print(contact.get(n)["tasks"].get(a))
        else:
            print("Task not found")
    else:
        print("Name not found")

def clean(x):
    x=x.replace("/","")
    return(x)
def add_eve():
    n=input("name:",)
    if namet(n):
        a=input("add event: ")
        event=[]
        eventd=[]
        eventd1=[]
        eventt=[]
        event.append(a)
        e=input("date(yy/mm/dd): ")
        eventd.append(clean(e))
        eventd1.append(e)
        s=input("time")
        eventt.append(s)
        contact[n].update({"events":[event,eventd,eventd1,eventt]})
        print("Event saved successfully!")
        for i in range(len(event)):
            print("Event:",event[i],"Date:",eventd1[i],"Time:",eventt[i])
    else:
        print("name not found")
    
def lest_eve():
    n=input("name:")
    if namet(n):
        event=contact.get(n)["events"][0]
        eventd=contact.get(n).get("events")[1]
        eventd1=contact.get(n).get("events")[2]
        eventt=contact.get(n).get("events")[3]
        test=False
        while test==False:
            test=True
            for i in range(len(event)-1):
                if eventd[i+1]<eventd[i]:
                        event[i+1],event[i]=permutation(event[i+1],event[i])
                        eventd1[i+1],eventd1[i]=permutation(eventd1[i+1],eventd1[i])
                        eventt[i+1],eventt[i]=permutation(eventt[i+1],eventt[i])
                        eventd[i+1],eventd[i]=permutation(eventd[i+1],eventd[i])
                        test=False
            w1,w2,w3=format_(event),format_(eventd1),format_(eventt)
            f.l1.setText(w1[0])
            f.a1.setText(w2[0])
            f.z1.setText(w3[0])
            f.l2.setText(w1[1])
            f.a2.setText(w2[1])
            f.z2.setText(w3[1])
            f.l3.setText(w1[2])
            f.a3.setText(w2[2])
            f.z3.setText(w3[2])
            f.l4.setText(w1[3])
            f.a4.setText(w2[3])
            f.z4.setText(w3[3])
            f.l5.setText(w1[4])
            f.a5.setText(w2[4])
            f.z5.setText(w3[4])
            print("name found! Check your app")
    else:
        print("name not found")
def delete_event():
    n=input("name: ")
    if namet(n):
        event=contact.get(n)["events"][0]
        eventd=contact.get(n).get("events")[1]
        eventd1=contact.get(n).get("events")[2]
        eventt=contact.get(n).get("events")[3]
        e=input("name of the event to delete: ")
        if e in event:
            q=event.index(e)
            event.pop(q)
            eventd.pop(q)
            eventd1.pop(q)
            eventt.pop(q)
            print("Event deleted successfully")
        else:
            print("Event not found")
    else:
        print("name not found")
def add_note():
    n=input("name:")
    if namet(n):
        a=input("add a note")
        contact[n]["notes"]+=[a]
        print(contact[n]["notes"])
        print(contact[n])
        print("Note successfully added!")
    else:
        print("name not found")
def print_notes():
    n=input("name: ")
    if namet(n):
        t=contact[n]["notes"][:]
        while len(t)!=3:
            t.append("-")
        f.l1.setText(t[0])
        f.a1.setText(t[1])
        f.z1.setText(t[2])
        f.l2.setText("")
        f.a2.setText("")
        f.z2.setText("")
        f.l3.setText("")
        f.a3.setText("")
        f.z3.setText("")
        f.l4.setText("")
        f.a4.setText("")
        f.z4.setText("")
        f.l5.setText("")
        f.a5.setText("")
        f.z5.setText("")
    else:
        print("name not found")
def show_all():
    l=list(contact.keys())
    while len(l)!=6:
        l.append("-")
    f.l1.setText(l[0])
    f.a1.setText(l[1])
    f.z1.setText(l[2])
    f.l2.setText(l[3])
    f.a2.setText(l[4])
    f.z2.setText(l[5])
    f.l3.setText("")
    f.a3.setText("")
    f.z3.setText("")
    f.l4.setText("")
    f.a4.setText("")
    f.z4.setText("")
    f.l5.setText("")
    f.a5.setText("")
    f.z5.setText("")

app=QApplication([])
f=loadUi("Majd Laarif project.ui")
f.addcontact.clicked.connect(add)
f.search.clicked.connect(search_n)
f.edit_n.clicked.connect(edit)
f.dell.clicked.connect(delete)
f.addtask.clicked.connect(add_task)
f.sort.clicked.connect(sort_task)
f.complete.clicked.connect(task_c)
f.add_event.clicked.connect(add_eve)
f.lest_dis.clicked.connect(lest_eve)
f.delete_eve.clicked.connect(delete_event)
f.notes.clicked.connect(add_note)
f.note.clicked.connect(print_notes)
f.show_al.clicked.connect(show_all)
f.show()
app.exec_()